CARCOMPARE AI PROTOTYPE

How to use:
1. Open index.html in a web browser.
2. Select two different vehicles.
3. Click "Compare Cars."
4. Review specifications, summarized feedback, and the recommendation.

This is a classroom prototype. The vehicle data is sample data for demonstration.
